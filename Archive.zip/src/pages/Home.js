import React from 'react';
import './Home.css';


const Home = () => {
  return (
    <div>
      <h1>Welcome to the Game of Thrones App</h1>
      <p>Explore the characters and houses of Westeros!</p>
    </div>
  );
};

export default Home;


